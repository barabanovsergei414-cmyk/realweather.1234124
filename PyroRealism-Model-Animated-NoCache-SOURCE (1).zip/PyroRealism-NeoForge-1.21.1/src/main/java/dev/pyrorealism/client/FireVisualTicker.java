package dev.pyrorealism.client;

import dev.pyrorealism.PyroRealism;
import dev.pyrorealism.registry.PyroParticles;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CampfireBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;

@EventBusSubscriber(modid = PyroRealism.MOD_ID, value = Dist.CLIENT)
public final class FireVisualTicker {
    private static int tickCounter;

    private FireVisualTicker() {}

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null || minecraft.isPaused()) {
            return;
        }

        // Scan every four ticks; each source emits one complete model-derived
        // plume every 32 ticks. The 32-tick lifetime makes the flipbook loop
        // continuous without a cloud of overlapping sphere particles.
        if (++tickCounter % 4 != 0) {
            return;
        }

        var level = minecraft.level;
        BlockPos center = minecraft.player.blockPosition();
        BlockPos.MutableBlockPos cursor = new BlockPos.MutableBlockPos();
        int processed = 0;
        final int maxSourcesPerPass = 10;
        final int radius = 9;

        scan:
        for (int dy = -3; dy <= 6; dy++) {
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    cursor.set(center.getX() + dx, center.getY() + dy, center.getZ() + dz);
                    BlockState state = level.getBlockState(cursor);

                    boolean normalFire = state.is(Blocks.FIRE);
                    boolean soulFire = state.is(Blocks.SOUL_FIRE) || state.is(Blocks.SOUL_CAMPFIRE);
                    boolean campfire = (state.is(Blocks.CAMPFIRE) || state.is(Blocks.SOUL_CAMPFIRE))
                            && state.hasProperty(CampfireBlock.LIT) && state.getValue(CampfireBlock.LIT);

                    if (!normalFire && !soulFire && !campfire) {
                        continue;
                    }
                    if (++processed > maxSourcesPerPass) {
                        break scan;
                    }
                    spawnAt(level, cursor, soulFire, campfire);
                }
            }
        }
    }

    private static void spawnAt(net.minecraft.client.multiplayer.ClientLevel level, BlockPos pos,
                                boolean soulFire, boolean campfire) {
        var random = level.random;

        // Stable phase offset per block prevents all nearby fires from pulsing
        // on the same tick while preserving a gap-free animation loop.
        int phase = Math.floorMod(pos.hashCode(), 8);
        if (Math.floorMod((tickCounter / 4) + phase, 8) == 0) {
            double x = pos.getX() + 0.5 + (random.nextDouble() - 0.5) * 0.025;
            double z = pos.getZ() + 0.5 + (random.nextDouble() - 0.5) * 0.025;
            double baseY = pos.getY() + (campfire ? 0.66 : 0.08);
            double plumeSize = soulFire ? 3.05 : 3.25;

            // The particle is centered half its height above the fire so the
            // source mesh's bottom edge begins at the burning block.
            level.addParticle(soulFire ? PyroParticles.SOUL_PLUME.get() : PyroParticles.PLUME.get(),
                    x, baseY + plumeSize * 0.49, z, 0.0, 0.0, 0.0);
        }

        // Keep a small number of embers separate from the model-based main plume.
        if (!campfire && random.nextFloat() < (soulFire ? 0.035F : 0.055F)) {
            double x = pos.getX() + 0.5;
            double y = pos.getY() + 0.18;
            double z = pos.getZ() + 0.5;
            level.addParticle(PyroParticles.EMBER.get(), x, y, z,
                    (random.nextDouble() - 0.5) * 0.008,
                    0.025 + random.nextDouble() * 0.025,
                    (random.nextDouble() - 0.5) * 0.008);
        }

        // Broad visual bloom near the base. This is a render effect and does
        // not modify Minecraft's underlying block-light map.
        if (random.nextFloat() < 0.20F) {
            double x = pos.getX() + 0.5;
            double y = pos.getY() + (campfire ? 0.75 : 0.22);
            double z = pos.getZ() + 0.5;
            level.addParticle(soulFire ? PyroParticles.SOUL_GLOW.get() : PyroParticles.GLOW.get(),
                    x, y, z, 0.0, 0.0, 0.0);
        }
    }
}
