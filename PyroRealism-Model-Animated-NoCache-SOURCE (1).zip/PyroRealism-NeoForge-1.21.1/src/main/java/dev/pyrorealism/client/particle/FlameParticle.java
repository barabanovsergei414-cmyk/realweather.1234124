package dev.pyrorealism.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/** Small, flickering tongues layered over the animated vanilla fire sprite. */
public final class FlameParticle extends TextureSheetParticle {
    private final SpriteSet sprites;
    private final float initialSize;
    private final double phase;
    private final boolean soul;

    public FlameParticle(ClientLevel level, double x, double y, double z,
                         double xSpeed, double ySpeed, double zSpeed, SpriteSet sprites, boolean soul) {
        super(level, x, y, z, xSpeed, ySpeed, zSpeed);
        this.sprites = sprites;
        this.soul = soul;
        this.phase = this.random.nextDouble() * Math.PI * 2.0;
        this.initialSize = 0.30F + this.random.nextFloat() * 0.16F;
        this.quadSize = initialSize;
        this.lifetime = 17 + this.random.nextInt(10);
        this.gravity = -0.020F;
        this.friction = 0.90F;
        this.hasPhysics = false;
        this.xd = xSpeed;
        this.yd = ySpeed + 0.035 + this.random.nextDouble() * 0.012;
        this.zd = zSpeed;
        this.setSpriteFromAge(sprites);
        this.setColor(1.0F, 1.0F, 1.0F);
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        float p = this.age / (float)this.lifetime;
        double t = this.age * 0.82 + phase;
        double wave = Math.sin(t);
        this.xd += wave * 0.0014;
        this.zd += Math.cos(t * 0.83) * 0.0014;
        this.yd = Math.min(this.yd + 0.00025, 0.061);
        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.90;
        this.yd *= 0.985;
        this.zd *= 0.90;
        this.quadSize = initialSize * (0.84F + p * 0.34F) * (0.92F + (float)wave * 0.10F);
        this.alpha = Math.max(0.0F, 1.0F - p * 1.08F);
        this.setColor(1.0F, soul ? 1.0F : 0.96F - p * 0.12F, soul ? 1.0F : 0.80F - p * 0.35F);
        this.setSpriteFromAge(this.sprites);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public int getLightColor(float partialTick) { return 0x00F000F0; }

    public static final class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final boolean soul;
        public Provider(SpriteSet sprites, boolean soul) { this.sprites = sprites; this.soul = soul; }
        @Override
        public FlameParticle createParticle(SimpleParticleType type, ClientLevel level,
                                            double x, double y, double z,
                                            double xSpeed, double ySpeed, double zSpeed) {
            return new FlameParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, sprites, soul);
        }
    }
}
