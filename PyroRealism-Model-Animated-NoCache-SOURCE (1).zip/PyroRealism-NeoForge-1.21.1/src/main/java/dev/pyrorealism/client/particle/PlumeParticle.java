package dev.pyrorealism.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/**
 * One model-derived fire-and-smoke plume.
 *
 * The flipbook frames are rendered from the supplied Fire.obj mesh. A single
 * tall billboard keeps fire and smoke visually connected instead of emitting
 * many detached spherical puffs. The emitter respawns it at a fixed cadence,
 * making the 16-frame animation loop continuously in the world.
 */
public final class PlumeParticle extends TextureSheetParticle {
    private final SpriteSet sprites;
    private final float baseSize;
    private final double phase;
    private final boolean soul;

    public PlumeParticle(ClientLevel level, double x, double y, double z,
                         double xSpeed, double ySpeed, double zSpeed,
                         SpriteSet sprites, boolean soul) {
        super(level, x, y, z, xSpeed, ySpeed, zSpeed);
        this.sprites = sprites;
        this.soul = soul;
        this.phase = this.random.nextDouble() * Math.PI * 2.0;
        this.baseSize = (soul ? 3.05F : 3.25F) + this.random.nextFloat() * 0.16F;
        this.quadSize = this.baseSize;
        this.lifetime = 32;
        this.gravity = 0.0F;
        this.friction = 1.0F;
        this.hasPhysics = false;
        this.xd = xSpeed;
        this.yd = ySpeed;
        this.zd = zSpeed;
        this.alpha = 1.0F;
        this.setColor(soul ? 0.92F : 1.0F, soul ? 0.97F : 1.0F, 1.0F);
        this.setSpriteFromAge(sprites);
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;

        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }

        float progress = this.age / (float) this.lifetime;
        double t = this.age * 0.18 + this.phase;

        // Tiny movement prevents a rigid sticker look; the actual shape motion
        // comes from the model-derived animated frames.
        this.xd += Math.sin(t) * 0.00018;
        this.zd += Math.cos(t * 0.87) * 0.00018;
        this.move(this.xd, 0.00012, this.zd);
        this.xd *= 0.94;
        this.zd *= 0.94;

        float pulse = 1.0F + (float) Math.sin(t * 1.25) * 0.018F;
        this.quadSize = this.baseSize * pulse;

        float fadeIn = Math.min(1.0F, this.age / 2.0F);
        float fadeOut = Math.min(1.0F, (this.lifetime - this.age) / 2.0F);
        this.alpha = Math.max(0.0F, Math.min(fadeIn, fadeOut));
        this.setColor(soul ? 0.94F : 1.0F, soul ? 0.98F : 1.0F, 1.0F);
        this.setSpriteFromAge(this.sprites);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public int getLightColor(float partialTick) {
        // Full-bright makes the fire core remain visible at night. Smoke stays
        // charcoal because its pixel colors and alpha are baked into the frame.
        return 0x00F000F0;
    }

    public static final class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final boolean soul;

        public Provider(SpriteSet sprites, boolean soul) {
            this.sprites = sprites;
            this.soul = soul;
        }

        @Override
        public PlumeParticle createParticle(SimpleParticleType type, ClientLevel level,
                                            double x, double y, double z,
                                            double xSpeed, double ySpeed, double zSpeed) {
            return new PlumeParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, sprites, soul);
        }
    }
}
