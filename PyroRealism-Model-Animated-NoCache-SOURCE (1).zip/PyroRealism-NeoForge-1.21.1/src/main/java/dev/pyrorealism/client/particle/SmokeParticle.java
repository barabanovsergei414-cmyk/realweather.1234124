package dev.pyrorealism.client.particle;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/** A narrow, vertically stretched wisp. Overlapping wisps read as one turbulent smoke column. */
public final class SmokeParticle extends TextureSheetParticle {
    private final SpriteSet sprites;
    private final boolean dark;
    private final float baseSize;
    private final double phase;
    private final double drift;

    public SmokeParticle(ClientLevel level, double x, double y, double z,
                         double xSpeed, double ySpeed, double zSpeed,
                         SpriteSet sprites, boolean dark) {
        super(level, x, y, z, xSpeed, ySpeed, zSpeed);
        this.sprites = sprites;
        this.dark = dark;
        this.phase = this.random.nextDouble() * Math.PI * 2.0;
        this.drift = 0.00020 + this.random.nextDouble() * 0.00022;
        this.baseSize = (dark ? 0.72F : 0.78F) + this.random.nextFloat() * 0.12F;
        this.quadSize = baseSize * 0.72F;
        this.lifetime = (dark ? 145 : 125) + this.random.nextInt(dark ? 46 : 36);
        this.gravity = -0.018F;
        this.friction = 0.985F;
        this.hasPhysics = false;
        this.xd = xSpeed;
        this.yd = ySpeed + (dark ? 0.036 : 0.033);
        this.zd = zSpeed;
        this.alpha = dark ? 0.76F : 0.55F;
        this.setSpriteFromAge(sprites);
        this.setColor(dark ? 0.13F : 0.43F, dark ? 0.14F : 0.44F, dark ? 0.16F : 0.47F);
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }

        float p = this.age / (float) this.lifetime;
        double t = this.age * 0.105 + phase;
        // Gentle eddies: enough to disturb the column, not enough to detach it into separate puffs.
        this.xd += Math.sin(t) * drift + Math.sin(t * 0.47) * drift * 0.45;
        this.zd += Math.cos(t * 0.91) * drift + Math.cos(t * 0.39) * drift * 0.45;
        this.xd = clamp(this.xd, -0.012, 0.012);
        this.zd = clamp(this.zd, -0.012, 0.012);
        this.yd = Math.min(this.yd + 0.00016, dark ? 0.068 : 0.063);
        this.move(this.xd, this.yd, this.zd);
        this.xd *= 0.975;
        this.yd *= 0.998;
        this.zd *= 0.975;

        // Moderate growth keeps each segment soft and elongated instead of becoming a giant sphere.
        float growth = 0.72F + p * 0.62F;
        float flicker = 1.0F + (float)Math.sin(t * 0.73) * 0.035F;
        this.quadSize = baseSize * growth * flicker;

        float fadeIn = Math.min(1.0F, this.age / 8.0F);
        float fadeOut = (float)Math.pow(Math.max(0.0F, (this.lifetime - this.age) / (this.lifetime * 0.30F)), 1.25);
        this.alpha = (dark ? 0.78F : 0.56F) * fadeIn * fadeOut;

        if (dark) {
            // Soot is almost black near the flame and becomes a natural charcoal gray as it rises.
            float gray = 0.12F + p * 0.31F;
            this.setColor(gray, gray * 1.035F, gray * 1.09F);
        } else {
            float gray = 0.40F + p * 0.22F;
            this.setColor(gray, gray * 1.015F, gray * 1.04F);
        }
        this.setSpriteFromAge(this.sprites);
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    @Override
    public ParticleRenderType getRenderType() {
        return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    public static final class Provider implements ParticleProvider<SimpleParticleType> {
        private final SpriteSet sprites;
        private final boolean dark;
        public Provider(SpriteSet sprites, boolean dark) { this.sprites = sprites; this.dark = dark; }

        @Override
        public SmokeParticle createParticle(SimpleParticleType type, ClientLevel level,
                                            double x, double y, double z,
                                            double xSpeed, double ySpeed, double zSpeed) {
            return new SmokeParticle(level, x, y, z, xSpeed, ySpeed, zSpeed, sprites, dark);
        }
    }
}
