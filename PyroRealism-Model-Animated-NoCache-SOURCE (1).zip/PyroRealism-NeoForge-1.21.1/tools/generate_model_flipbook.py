#!/usr/bin/env python3
"""Regenerate the model-derived PyroRealism plume flipbook from source-models/Fire.obj.

Requires: numpy, Pillow, trimesh, vtk.
The committed PNG frames are already generated; this script is optional.
"""
from pathlib import Path
import math
import numpy as np
import trimesh
import vtk
from vtk.util.numpy_support import vtk_to_numpy
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
OBJ = ROOT / "source-models" / "Fire.obj"
OUT = ROOT / "src/main/resources/assets/pyrorealism/textures/particle"
SIZE = 128
FRAME_COUNT = 16

def load_simplified_mesh(path):
    reader = vtk.vtkOBJReader()
    reader.SetFileName(str(path))
    reader.Update()
    triangles = vtk.vtkTriangleFilter()
    triangles.SetInputConnection(reader.GetOutputPort())
    triangles.Update()
    decimator = vtk.vtkDecimatePro()
    decimator.SetInputConnection(triangles.GetOutputPort())
    decimator.SetTargetReduction(0.92)
    decimator.PreserveTopologyOn()
    decimator.SetFeatureAngle(45)
    decimator.Update()
    poly = decimator.GetOutput()
    vertices = vtk_to_numpy(poly.GetPoints().GetData()).copy()
    faces = vtk_to_numpy(poly.GetPolys().GetConnectivityArray()).reshape(-1, 3).copy()
    return vertices.astype(np.float64), faces.astype(np.int32)

def render_frame(vertices, faces, frame, soul=False):
    base_y, top_y = vertices[:, 1].min(), vertices[:, 1].max()
    tri0 = vertices[faces]
    original_centers = tri0.mean(axis=1)
    normals = np.cross(tri0[:, 1] - tri0[:, 0], tri0[:, 2] - tri0[:, 0])
    normals /= np.maximum(1e-9, np.linalg.norm(normals, axis=1, keepdims=True))
    bins = np.linspace(base_y, top_y, 32)
    centers, widths = [], []
    for lo, hi in zip(bins[:-1], bins[1:]):
        selection = (vertices[:, 1] >= lo) & (vertices[:, 1] < hi)
        if np.count_nonzero(selection) > 5:
            xs = vertices[selection, 0]
            centers.append((lo + hi) * 0.5)
            widths.append(((xs.min() + xs.max()) * 0.5, xs.max() - xs.min()))
    centers = np.asarray(centers)
    widths = np.asarray(widths)
    phase = 2 * np.pi * frame / FRAME_COUNT
    vv = vertices.copy()
    smoke = np.clip((vv[:, 1] - 2.2) / 4.3, 0, 1)
    flame = 1 - np.clip((vv[:, 1] - 2.45) / 1.0, 0, 1)
    w1 = np.sin(phase + vv[:, 1] * 3.7 + vv[:, 2] * 3.0 + vv[:, 0] * 1.5)
    w2 = np.sin(phase * 2 - vv[:, 1] * 6.1 + vv[:, 0] * 4.2)
    vv[:, 0] += (0.025 + 0.10 * flame + 0.16 * smoke) * w1 + (0.035 * flame + 0.055 * smoke) * w2
    vv[:, 2] += (0.025 + 0.08 * smoke) * np.cos(phase * 0.83 + vv[:, 1] * 2.2 + vv[:, 0] * 2.0)
    vv[:, 1] += (0.025 * flame + 0.055 * smoke) * np.sin(phase * 1.15 + vv[:, 0] * 3.1 + vv[:, 2] * 3.7)
    vv[:, 0] *= 1 + 0.10 * smoke * np.sin(phase * 0.7 + vv[:, 1] * 1.1)
    triangles = vv[faces]
    face_centers = triangles.mean(axis=1)
    px = vv[:, 0] + vv[:, 2] * 0.42
    py = vv[:, 1] + vv[:, 2] * 0.10
    xy = np.column_stack((64 + (px + 1.95) * 70 / 3.5 - 35,
                          120 - (py - (base_y - 0.10)) * 113 / (top_y - base_y + 0.22)))
    yc, xc = face_centers[:, 1], face_centers[:, 0]
    center = np.interp(np.clip(yc, centers.min(), centers.max()), centers, widths[:, 0])
    width = np.interp(np.clip(yc, centers.min(), centers.max()), centers, widths[:, 1])
    radial = np.minimum(1.5, np.abs(xc - center) / np.maximum(0.1, width * 0.5))
    light = np.array([0.18, 0.55, 0.82]); light /= np.linalg.norm(light)
    shade = 0.82 + 0.18 * np.maximum(0, normals @ light)
    fire_w = 1 / (1 + np.exp(np.clip((yc - 2.85) * 5, -40, 40)))
    smoke_w = 1 - fire_w
    p = np.clip((yc - base_y) / 2.45, 0, 1)
    core = np.exp(-np.square(radial / 0.60))
    if soul:
        fr, fg, fb = 55 + 100 * core, 125 + 115 * core, np.full_like(yc, 255)
    else:
        fr = np.full_like(yc, 255)
        fg = np.clip((95 + 160 * core) * (1 - 0.18 * p) * shade, 0, 255)
        fb = np.clip((4 + 115 * core) * (1 - 0.28 * p) * shade, 0, 255)
    sp = np.clip((yc - 2.55) / (top_y - 2.55), 0, 1)
    edge = np.maximum(0.42, 1 - radial * 0.25)
    texture = 7 * np.sin(yc * 10 + xc * 9 + frame * 0.55)
    gray = np.clip((55 + 78 * sp + texture) * shade * edge, 18, 180)
    if soul:
        sr, sg, sb = gray * 0.5, gray * 0.68, gray * 1.08
    else:
        sr, sg, sb = gray, np.minimum(190, gray * 1.03), np.minimum(205, gray * 1.08)
    rgb = np.column_stack((fr * fire_w + sr * smoke_w,
                           fg * fire_w + sg * smoke_w,
                           fb * fire_w + sb * smoke_w))
    sa = np.clip(200 - 115 * sp, 62, 200)
    alpha = (238 * fire_w + sa * smoke_w) * (0.94 + 0.06 * shade)
    colors = np.column_stack((np.clip(rgb, 0, 255), np.clip(alpha, 0, 255))).astype(np.uint8)
    image = Image.new("RGBA", (SIZE, SIZE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image, "RGBA")
    for idx in np.argsort(face_centers[:, 2]):
        draw.polygon([tuple(xy[j]) for j in faces[idx]], fill=tuple(int(c) for c in colors[idx]))
    return image.filter(ImageFilter.GaussianBlur(0.9))

def main():
    OUT.mkdir(parents=True, exist_ok=True)
    vertices, faces = load_simplified_mesh(OBJ)
    for frame in range(FRAME_COUNT):
        render_frame(vertices, faces, frame, False).save(OUT / f"plume_{frame}.png", optimize=True)
        render_frame(vertices, faces, frame, True).save(OUT / f"soul_plume_{frame}.png", optimize=True)

if __name__ == "__main__":
    main()
